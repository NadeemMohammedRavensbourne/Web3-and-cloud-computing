import React, { useState, useEffect } from "react";
import { getProductTransactions } from "../blockchain";
import { useParams } from "react-router-dom";

const ProductTransaction = () => {
  const [productTransaction, setProductTransaction] = useState([]);
  const { index } = useParams();
  console.log(index)

  useEffect(() => {
    const fetchProductTransaction = async () => {

      const result = await getProductTransactions(index);
      setProductTransaction(result);
      console.log(result)
    };

    fetchProductTransaction();
  }, []);

  return (
    <>
      <div className="h-screen w-screen flex  justify-center items-center bg-gradient-to-r from-slate-500 to-orange-300">
        <div className="grid w-[600px] h-auto gap-4 bg-slate-300 border rounded-xl p-4">
          <h1 className="font-bold text-2xl">Products Transaction History</h1>
          {productTransaction.map((tx, index) => {
            return (<div className="flex h-[15vh] w-full items-center relative ">
              <div className="rounded-full border-2 border-black h-1/2 w-[8vh] flex items-center justify-center  ">1
                {index != productTransaction.length - 1 && <div className="absolute w-[2px] bg-black h-[70%] top-[90%]  transform -translate-y-1/4"></div>}
              </div>
              <div className="pl-10 font-bold text-xl grid">{tx.action}
                <span className="text-sm">Seller: {tx.seller}</span>
                <span className="text-sm">Buyer: {tx.buyer}</span>
                <span className="text-sm">Price: {tx.price.toString()}</span>
              </div>

            </div>)
          })}
          {/* <div className="flex h-[15vh] w-full items-center relative ">
          <div className="rounded-full border-2 border-black h-1/2 w-[8vh] flex items-center justify-center ">2
          <div className="absolute w-[2px] bg-black h-[70%] top-[90%]  transform -translate-y-1/4"></div>
          </div>
          <div className="pl-10 font-bold text-xl grid">Distributor
          <span className="text-sm">Distributor Address: {productTransaction.producerAddress}</span>
          <span className="text-sm">Sale Price: {productTransaction.producerAddress}</span></div>
        </div> */}
          {/* <div className="flex h-[15vh] w-full items-center relative ">
          <div className="rounded-full border-2 border-black h-1/2 w-[8vh] flex items-center justify-center ">3
          <div className="absolute w-[2px] bg-black h-[70%] top-[90%]  transform -translate-y-1/4"></div>
          </div>
          <div className="pl-10 font-bold text-xl grid">Retialer
          <span className="text-sm">Retailer Address: {productTransaction.producerAddress}</span>
          <span className="text-sm">Sale Price: {productTransaction.producerAddress}</span></div>
        </div> */}
          {/* <div className="flex h-[15vh] w-full items-center">
          <div className="rounded-full border-2 border-black h-1/2 w-[8vh] flex items-center justify-center">4</div>
          <div className="pl-10 font-bold text-xl grid">Consumer
          <span className="text-sm">Consumer Address: {productTransaction.producerAddress}</span>
          <span className="text-sm">Sale Price: {productTransaction.producerAddress}</span></div>
        </div> */}
        </div>
      </div >

    </>
  );
};

export default ProductTransaction;
