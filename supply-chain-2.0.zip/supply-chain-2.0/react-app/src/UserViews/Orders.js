import React, { useState, useEffect } from "react";

const Orders = () => {
  const [products, setProducts] = useState([
    { id: 1, productId: 1, name: "Soap", salePrice: 100 , status: "fulfilled"},
    { id: 2, productId: 2, name: "Shampo", salePrice: 100,status: "rejected" },
  ]);

  useEffect(() => {
    const fetchProducts = () => {
      // Logic to fetch products from blockchain or backend
      // For now, use dummy data
      // const result = await getAllproducts();
      // setProducts(result);
    };

    fetchProducts();
  }, []);

 

  return (
    <div className="h-screen w-screen flex flex-col justify-start items-center bg-gradient-to-r from-slate-500 to-orange-300">
      <div className="flex justify-between h-[10vh] items-center w-full px-4 bg-slate-200">
        <h2 className="font-bold text-2xl">My Products Orders</h2>
        
      </div>
      <table className="mx-11  mt-8 w-3/4">
        <thead className="bg-gray-200">
          <tr>
            <th className="px-4 py-2">Product Id</th>
            <th className="px-4 py-2">Product Name</th>
            <th className="px-4 py-2">Price</th>
            <th className="px-4 py-2">Status</th>     
          </tr>
        </thead>
        <tbody>
          {products.map((product) => (
            <tr key={product.id} className=" hover:bg-gray-400 even:bg-amber-100 odd:bg-white">
              <td className="border px-4 py-2">{product.productId}</td>
              <td className="border px-4 py-2">{product.name}</td>
              <td className="border px-4 py-2">{product.salePrice}</td>
              <td className="border px-4 py-2">{product.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Orders;
