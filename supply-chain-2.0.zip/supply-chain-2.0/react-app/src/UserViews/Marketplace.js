import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { addTransaction, getAllProducts } from "../blockchain";

const Marketplace = () => {
  const [products, setProducts] = useState([]);
  const [success, setSuccess] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProducts = async () => {
      const result = await getAllProducts()

      setProducts(result);
      console.log(result);
    };

    fetchProducts();
  }, []);

  const buyProduct = async (productId, price) => {
    const result = await addTransaction(productId, price, "Retailer > Consumer", localStorage.getItem('address'));
    if (result) {
      setSuccess(true);
      await sleep(3000);
      setSuccess(false);

    }
  };

  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  const productTransaction = (index) => {
    navigate(`/product-transaction/${index}`);
  };



  const myOrders = () => {
    navigate("/my-orders");
  };

  return (
    <div className="h-screen w-screen flex flex-col justify-start items-center bg-gradient-to-r from-slate-500 to-orange-300">
      <div className="flex justify-between h-[10vh] items-center w-full px-4 bg-slate-200">
        <h2 className="font-bold text-2xl">All Available Products</h2>
      </div>
      <table className="mx-11  mt-8 w-3/4">
        <thead className="bg-gray-200">
          <tr>
            <th className="px-4 py-2">Product Id</th>
            <th className="px-4 py-2">Product Name</th>
            <th className="px-4 py-2">Price</th>
            <th className="px-4 py-2">History</th>
            <th className="px-4 py-2">Order Now</th>
          </tr>
        </thead>
        <tbody>
          {products?.map((product, index) => (
            <tr
              key={index}
              className=" hover:bg-gray-400 even:bg-amber-100 odd:bg-white"
            >
              <td className="border px-4 py-2">{index + 1}</td>
              <td className="border px-4 py-2">{product.name}</td>
              <td className="border px-4 py-2">{product.price.toString()}</td>
              <td className="border px-4 py-2 w-[250px]">
                <button
                  className="relative py-2 px-8 text-black text-base font-bold rounded-full overflow-hidden bg-gray-300 transition-all duration-400 ease-in-out shadow-md hover:scale-105 hover:text-white hover:shadow-lg active:scale-90 before:absolute before:top-0 before:-left-full before:w-full before:h-full before:bg-gradient-to-r before:from-blue-500 before:to-blue-300 before:transition-all before:duration-500 before:ease-in-out before:z-[-1] before:rounded-full hover:before:left-0"
                  onClick={() => productTransaction(parseInt(product.id.toString()))}
                >
                  View Transaction
                </button>
              </td>
              <td className="border px-4 py-2 w-[20px]">
                <button
                  className="relative py-2 px-8  text-black text-base font-bold rounded-full overflow-hidden bg-gray-300 transition-all duration-400 ease-in-out shadow-md hover:scale-105 hover:text-white hover:shadow-lg active:scale-90 before:absolute before:top-0 before:-left-full before:w-full before:h-full before:bg-gradient-to-r before:from-blue-500 before:to-blue-300 before:transition-all before:duration-500 before:ease-in-out before:z-[-1] before:rounded-full hover:before:left-0"
                  onClick={() => buyProduct(parseInt(product.id.toString()), parseInt(product.price.toString()))}
                >
                  Buy
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {success && <p>Transaction Successful</p>}
    </div>
  );
};

export default Marketplace;
